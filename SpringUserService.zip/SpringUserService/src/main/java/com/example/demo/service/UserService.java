package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.VO.Department;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class UserService {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	public User saveUser(User user) {
		return userRepository.save(user);
	}

	public User getUserById(Long userId) {
		return userRepository.findByUserId(userId);
	}

	public Department getUserWithDepartment(Long DepartmentId) {
		return restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/" + DepartmentId, Department.class);
	}

}
